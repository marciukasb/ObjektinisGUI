﻿using System;
using System.Drawing;

namespace GraphicalInterface.SimpleMapPainter
{
    public interface IMapPainter
    {
        void Draw(Graphics g);
    }
}
